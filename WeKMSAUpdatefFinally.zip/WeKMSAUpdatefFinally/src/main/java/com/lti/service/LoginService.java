package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.Admin;
import com.lti.model.NGOReg;
import com.lti.model.Registration;
import com.lti.repository.DaoWe;

@Service("loginService")
public class LoginService {

	@Autowired
	private DaoWe dao;

	@Transactional
	public Registration checkLoginUser(String username, String password) {
		Registration a = dao.readUserLogin(username, password);
		return a;
	}
	
	@Transactional
	public NGOReg checkLoginNGO(String email, String password) {
		NGOReg a = dao.readNGOLogin(email, password);
		return a;
	}
	
	
	
	@Transactional
	public Admin checkLoginAdmin(String username, String password) {
		Admin a = dao.readNGOAdmin(username, password);
		return a;
	}
	
}
