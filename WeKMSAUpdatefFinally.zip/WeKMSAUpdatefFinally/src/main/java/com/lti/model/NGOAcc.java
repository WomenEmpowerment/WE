package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "NGO_ACCOMODATION")
public class NGOAcc {

	@Id
	@GeneratedValue
	@Column(name = "NGO_ACC_ID")
	private int ngoaccid;

	@Column(name = "ROOMS_AVAILABLE")
	private int roomAvail;

	@Column(name = "NGO_ACC_CITY")
	private String ngoacccity;

	@OneToOne
	@JoinColumn(name = "NGO_ID")
	private NGOReg ngoreg;

	public int getNgoaccid() {
		return ngoaccid;
	}

	public int getRoomAvail() {
		return roomAvail;
	}

	public void setRoomAvail(int roomAvail) {
		this.roomAvail = roomAvail;
	}

	public String getNgoacccity() {
		return ngoacccity;
	}

	public void setNgoacccity(String ngoacccity) {
		this.ngoacccity = ngoacccity;
	}

	public NGOReg getNgoreg() {
		return ngoreg;
	}

	public void setNgoreg(NGOReg ngoreg) {
		this.ngoreg = ngoreg;
	}

	@Override
	public String toString() {
		return "NGOAcc [ngoaccid=" + ngoaccid + ", roomAvail=" + roomAvail + ", ngoacccity=" + ngoacccity + ", ngoreg="
				+ ngoreg + "]";
	}

	
}
