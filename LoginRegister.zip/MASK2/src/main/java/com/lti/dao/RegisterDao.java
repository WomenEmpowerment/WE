package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.register;



@Repository
public class RegisterDao {

	@PersistenceContext
	private EntityManager entitymanager;
	
	@Transactional
   public void addEntry(register registration) {
		entitymanager.persist(registration);
	}
		
		
		public String readUserLogin(String username,String password)
		{
			
			String qu="select a from register as a where a.username=:username and a.password=:password";
			Query q1=entitymanager.createQuery(qu);
			q1.setParameter("username",username);
			q1.setParameter("password",password);
			List list=q1.getResultList();
			if((list!=null)&&(list.size()>0))
			{
				//System.out.println("Approved");
				return "Approved";
			}
			
			System.out.println("Wrong Username and Password");
			return "Wrong Username";
		}
		
   }
	
	

